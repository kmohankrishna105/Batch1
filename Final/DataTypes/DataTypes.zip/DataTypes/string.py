# Python Program for
# Creation of String

# Creating a String
# with single Quotes
String1 = 'Welcome to the Automation World'
print("String with the use of Single Quotes: ")
print(String1)

# Creating a String
# with double Quotes
String1 = "I'm a QA"
print("\nString with the use of Double Quotes: ")
print(String1)
print(type(String1))

# Creating a String
# with triple Quotes
String1 = '''This is how a Automation code should work"'''
print("\nString with the use of Triple Quotes: ")
print(String1)
print(type(String1))
"""
#Slicing and Indexing
Automation is important
0123456789...........20
-21,-20,-19...........-1
"""

# Python Program to Access
# characters of String

String1 = "Python Automation"
print("Initial String: ")
print(String1)

# Printing First character
print("\nFirst character of String is: ")
print(String1[0])

# Printing Last character
print("\nLast character of String is: ")
print(String1[-1])

print(String1.lower())
print(String1.upper())
print(String1.replace("Python","Advanced"))

name= "    Python   "
print(name.strip())

str1= "automation"
print(str1.capitalize())


